import java.sql.SQLException;

public class MyException extends Exception {
	
	MyException(InvalidAccountException e){
		
	}
	MyException(SQLException e){
		
	}MyException(InsufficientBalanceException e){
		
	}
	

	
}
