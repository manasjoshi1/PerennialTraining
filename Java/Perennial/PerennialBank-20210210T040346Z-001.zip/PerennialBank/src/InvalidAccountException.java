
public class InvalidAccountException extends Exception {

}
